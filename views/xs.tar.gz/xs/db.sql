drop table if exists `member`;
create table `member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'member ID',
  `mail` varchar(128) NOT NULL DEFAULT '',
  `pwd` varchar(128) NOT NULL DEFAULT '',
  `name` varchar(32) NOT NULL DEFAULT '',
  `site` varchar(128) DEFAULT NULL COMMENT '个人网站',
  `create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `company` varchar(256) DEFAULT NULL,
  `job` varchar(256) DEFAULT NULL,
  `location` varchar(128) DEFAULT NULL,
  `sign` varchar(512) DEFAULT NULL,
  `profile` varchar(1024) DEFAULT NULL,
  `avatar` varchar(128) DEFAULT NULL,
  `is_block` char(1) NOT NULL DEFAULT 'F',
  `balance` varchar(10) NOT NULL DEFAULT '0',
  PRIMARY KEY(`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='注册会员表';

drop table if exists `node_coll`;
create table `node_coll` (
  `mid` int(10) unsigned NOT NULL COMMENT 'member ID',
  `nodeid` int(10) unsigned NOT NULL COMMENT 'NODE ID',
  primary key(`mid`,`nodeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='节点收藏表';

drop table if exists `topic_coll`;
create table `topic_coll` (
  `mid` int(10) unsigned NOT NULL COMMENT 'member ID',
  `topicid` int(10) unsigned NOT NULL COMMENT 'topic ID',
  primary key(`mid`,`topicid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='主题收藏表';

drop table if exists `follow`;
create table `follow` (
  `mid` int(10) unsigned NOT NULL COMMENT 'member ID',
  `fid` int(10) unsigned NOT NULL COMMENT 'follow ID',
  primary key(`mid`,`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='特别关注表';

drop table if exists `ignore_m`;
create table `ignore_m` (
  `mid` int(10) unsigned NOT NULL COMMENT 'member ID',
  `iid` int(10) unsigned NOT NULL COMMENT 'ignore ID',
  primary key(`mid`,`iid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='屏蔽其他会员表';

drop table if exists `ignore_n`;
create table `ignore_n` (
  `mid` int(10) unsigned NOT NULL COMMENT 'member ID',
  `nodeid` int(10) unsigned NOT NULL COMMENT 'node ID',
  primary key(`mid`,`nodeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='忽略节点表';

drop table if exists `ignore_t`;
create table `ignore_t` (
  `mid` int(10) unsigned NOT NULL COMMENT 'member ID',
  `topicid` int(10) unsigned NOT NULL COMMENT 'topic ID',
  primary key(`mid`,`topicid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='忽略主题表';

drop table if exists `notify`;
create table `notify` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL COMMENT '主动方',
  `rmid` int(10) unsigned NOT NULL COMMENT '被动方',
  `notify_type` tinyint(1) NOT NULL COMMENT '通知类型:comment,post_at,comment_at',
  `foreign_id` int(10) NOT NULL COMMENT 'topic-id,comment-id',
  `unread` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY(`id`),
  INDEX rmid_index(`rmid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='通知表';

drop table if exists `notify_t`;
create table `notify_t` (
  `id` tinyint(1) NOT NULL,
  `name` varchar(10) NOT NULL,
  `comment` varchar(32) NOT NULL,
  PRIMARY KEY(`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='通知类型表';

LOCK TABLES `notify_t` WRITE;
INSERT INTO `notify_t` (`id`, `name`, `comment`)
VALUES
	(1,'comment','收到评论'),
	(2,'post_at','在帖子中提及'),
	(3,'comment_at','在回复中提及');
UNLOCK TABLES;

/* 以上为会员相关表 */

drop table if exists `topic`;
create table `topic` (
  `id` int(10) unsigned NOT NULL COMMENT 'topic ID',
  `mid` int(10) unsigned NOT NULL COMMENT 'member ID',
  `nodeid` int(10) unsigned NOT NULL COMMENT 'node id',
  `title` text NOT NULL COMMENT '标题',
  `content` text DEFAULT NULL,
  `time`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `views` int(10) DEFAULT 0 COMMENT '浏览数',
  `comments` int(10) DEFAULT 0 COMMENT '评论数',
  `colls` int(10) DEFAULT 0 COMMENT '被收藏数',
  `thanks` int(10) DEFAULT 0 COMMENT '被感谢数',
  `last` timestamp,
  PRIMARY KEY(`id`),
  INDEX mid_index(`mid`),
  INDEX nodeid_index(`nodeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='主题表';

drop table if exists `topic_thx`;
create table `topic_thx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL,
  `topicid` int(10) unsigned NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(`id`),
  INDEX mid_topicid(`mid`,`topicid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='主题感谢表';

drop table if exists `comment`;
create table `comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL,
  `topicid` int(10) unsigned NOT NULL,
  `content` text COMMENT '评论内容',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `thanks` int(10) DEFAULT 0 COMMENT '被感谢数',
  PRIMARY KEY(`id`),
  INDEX topicid_index(`topicid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评论表';

drop table if exists `comment_thx`;
create table `comment_thx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL,
  `commentid` int(10) unsigned NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(`id`),
  INDEX mid_commentid(`mid`,`commentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评论感谢表';

drop table if exists `category`;
create table `category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL COMMENT '节点分类名字',
  `display_name` varchar(32) NOT NULL COMMENT '节点显示名',
  `description` text NOT NULL COMMENT '分类描述',
  PRIMARY KEY(`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='节点分类表';

DROP TABLE IF EXISTS `node`;
CREATE TABLE `node` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(32) NOT NULL COMMENT '节点名',
  `display_name` varchar(32) NOT NULL COMMENT '节点显示名',
  `description` text COMMENT '描述',
  `icon` varchar(64) DEFAULT NULL COMMENT '图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='节点表';
