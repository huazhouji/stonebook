var db = require('./db.js');
var md5 = require('./md5');

exports.signup_verify = function(name,cb) {
  db.sql("select id from member where name=?",[name],function(err,rows) {
    if(err) cb(err);
    else{
      if(rows.length>0) cb("registered");
      else cb(null);
    }
  });
}

exports.dosignup = function(name,pwd,mail,cb) {
  db.sql("insert into member set ?", {name:name, pwd:md5(pwd), mail:mail}, function(err, rows){
    if(err) cb(err);
    else cb(null);
  });
}

exports.dosignin = function(name, pwd, cb) {
  db.sql("select id from member where name=? and pwd=?", [name,md5(pwd)], function(err,rows) {
    if(err) cb(err);
    else {
      if(rows.length<=0) {
	cb('no-such-member');
      }else{
	cb(null, rows[0].id);
      }
    }
  });
}
