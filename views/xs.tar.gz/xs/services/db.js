var mysql = require('mysql');
var log = require('./log');

var pool  = mysql.createPool({
  host     : '127.0.0.1',
  database : 'xs',
  user     : 'root',
  password : 'l86320364y'
});

exports.sql = function(sql, values, callback) {
  try{
        pool.getConnection(function(err, connection) {
                if(err){
                        log.error('get-conn:%j', err);
                        if(callback) callback(err);
                        return;
                }

                connection.query(sql, values, function(err, rows) {
                        if (err){
                                log.error('DB-Error:%j,%s,%j\n', err, sql,values);
                        }else{
                                log.debug('sql: %s,%j\n -> %j', sql,values, rows);
                        }

                        connection.release();

                        if(callback) callback(err, rows);
                });
        });
  }catch(e){
        log.error('sql-exec:%j', e);
        if(callback) callback(e);
  }
}
