var winston = require('winston');
var config = require('../config.js');
var path = require('path');

winston.loggers.add('common', {
    console: {
      silent: !config.debug,
      level: 'debug',
      colorize: true,
      timestamp: true
    },
    file: {
      silent: config.debug,
      level: 'debug',
      colorize: true,
      timestamp: true,
      json: false,
      maxsize: 1024*1024*200,
      maxFiles: 10,
      filename: path.join(__dirname, '../log')
    }
  });

module.exports = winston.loggers.get('common');

