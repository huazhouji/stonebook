var config = require('../config.js');
var Recaptcha = require('recaptcha').Recaptcha;
var log = require('../services/log.js');
var member = require('../services/member');
var v = require('validator');
var xss = require('xss');

exports.signup = function(req, res) {
  if(req && req.method=='GET') {
    var recaptcha = new Recaptcha(config.recaptcha_pub, config.recaptcha_pri);
    res.render(req.ua + '/sign/signup.html', { "recaptcha_html": recaptcha.toHTML() } );

  }else if(req && req.method=='POST'){
    var name = xss(v.trim(req.param('username')));
    var mail = xss(v.trim(req.param('email')));
    var pwd = xss(v.trim(req.param('password')));
  
    var data = {
        remoteip:  req.connection.remoteAddress,
        challenge: req.body.recaptcha_challenge_field,
        response:  req.body.recaptcha_response_field
    };
    var recaptcha = new Recaptcha(config.recaptcha_pub, config.recaptcha_pri, data);
 
    if(v.isNull(name)){
      res.render(req.ua + '/sign/signup.html', { problem: true, mail: mail, name: name, name_null: true, "recaptcha_html": recaptcha.toHTML() });
      return;
    } 
    if(v.isNull(pwd)){
      res.render(req.ua + '/sign/signup.html', { problem: true, mail: mail, name: name, pwd_null: true, "recaptcha_html": recaptcha.toHTML() });
      return;
    }
    if(!v.isEmail(mail)){
      res.render(req.ua + '/sign/signup.html', { problem: true, mail: mail, name: name, mail_invalid: true, "recaptcha_html": recaptcha.toHTML() });
      return;
    }
    
    recaptcha.verify(function(success, error_code) {
        if (success) {
	    if(name && name.length<=32) {
  	      member.signup_verify(name,function(err){
	  	if(err=='registered') res.render(req.ua + '/sign/signup.html', { problem: true, mail: mail, name: name, duplicate: true, "recaptcha_html": recaptcha.toHTML() });
		else if(err!=null){  res.render('500.html'); }
		else {
		  // do sign up
		  member.dosignup(name,pwd,mail, function(err){
		    if(err) res.render('500.html');
		    else  res.redirect('/balance.html');//TODO
		  });
		}
	      });
	    }else{
	      res.render(req.ua + '/sign/signup.html', { problem: true, name_length_invalid: true, "recaptcha_html": recaptcha.toHTML(),mail: mail, name: name });
	    }
        }
        else {
	    res.render(req.ua + '/sign/signup.html', { problem: true, captcha_invalid: true, "recaptcha_html": recaptcha.toHTML(),mail: mail, name: name });
        }
    });
  }else{
    log.error('signup request method invalid');
    res.send('');    
  } 
}

exports.signin = function(req, res) {
  if(req && req.method=='GET') {
    res.render(req.ua + '/sign/signin.html');
  }else if(req && req.method=='POST'){
    var name = xss(v.trim(req.param('u'))); 
    var pwd = xss(v.trim(req.param('p')));
    
    if(v.isNull(name) || v.isNull(pwd)) {
      res.render(req.ua + '/sign/signin.html');
      return;
    }

    member.dosignin(name, pwd, function(err, id) {
      if(err=='no-such-member') res.render(req.ua + '/sign/signin.html', { problem: true, no_such_member: true });
      else if(err) res.render('500');
      else {
	// TODO signin success
      }
    });
  }else{
    log.error('signin request method invalid');
    res.send('');
  }
}

exports.signout = function(req, res) {

}

