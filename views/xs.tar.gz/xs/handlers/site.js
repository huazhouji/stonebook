var config = require('../config.js');
var Recaptcha = require('recaptcha').Recaptcha;

exports.index = function(req, res) {
  res.render(req.ua + '/index');
}

exports.signup = function(req, res) {
  if(req && req.method=='GET') {
    var recaptcha = new Recaptcha(config.recaptcha_pub, config.recaptcha_pri);
    res.render(req.ua + '/sign/signup.html', { "recaptcha_html": recaptcha.toHTML() } );
  }else{
    var data = {
	remoteip:  req.connection.remoteAddress,
        challenge: req.body.recaptcha_challenge_field,
        response:  req.body.recaptcha_response_field
    };
    var recaptcha = new Recaptcha(config.recaptcha_pub, config.recaptcha_pri, data);
    recaptcha.verify(function(success, error_code) {
        if (success) {
            res.send('succ');
        }
        else {
            res.send('Recaptcha response valid.');
        }
    });
  } 
};
