
var config = {
	port: 80,
	session_secret: 'lyisawesome',
	domain: 'qunady.com',
	title: '萧山小道消息',
	debug: false,
	recaptcha_pub: '6LcxvO8SAAAAADJoYFUDOrgM_FaiwmGRi3zDv7-7',
	recaptcha_pri: '6LcxvO8SAAAAAF96NMCmzFSsSLedR1Qt7dHIw2sd'
}

module.exports = config;
