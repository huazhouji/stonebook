var config = require('./config');
var site = require('./handlers/site');
var sign = require('./handlers/sign');

module.exports = function (app) {
  app.get('/', site.index); 

  app.get('/signup', sign.signup);
  app.post('/signup', sign.signup);
  app.get('/signin', sign.signin);
  app.post('/signin', sign.signin);

 
};
