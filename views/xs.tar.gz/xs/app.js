var express = require('express');                                                                            
var routes = require('./routes');                                                                            
var http = require('http');                                                                                  
var swig = require('swig');                                                                                  
var config = require('./config');
var passport = require('passport');
var mkdirp = require('./mkdirp');
var path = require('path');
var log = require('./services/log.js');

var maxAge = 3600000 * 24 * 30;
var staticDir = path.join(__dirname, 'public');

config.upload_dir = config.upload_dir || path.join(__dirname, 'public', 'user_data', 'images');                                                             
mkdirp.mkdirpSync(config.upload_dir);

var app = express();                                                                                         

app.engine('html', swig.renderFile);                                                                         
app.set('port', config.port || 80);                                                                     
app.set('views', path.join(__dirname, 'views'));                                                             
app.set('view engine', 'html');                                                                              
swig.setDefaults({ cache: false });
swig.setDefaults({ locals: { defaultTitle: config.title, defaultDomain: config.domain }});

app.use(express.bodyParser({
  uploadDir: config.upload_dir
}));
app.use(express.methodOverride());
app.use(express.cookieParser());
app.use(express.session({
  secret: config.session_secret
}));
app.use(passport.initialize());
// custom middleware
// app.use(require('./controllers/sign').auth_user);
// app.use(auth.blockUser());
app.use('/upload/', express.static(config.upload_dir, { maxAge: maxAge }));
// old image url: http://host/user_data/images/xxxx
app.use('/user_data/', express.static(path.join(__dirname, 'public', 'user_data'), { maxAge: maxAge }));

if (config.debug) {
  app.use('/public', express.static(staticDir));
  app.use(express.errorHandler({ dumpExceptions: true, showStack: true }));
} else {
  app.use(express.csrf());
  app.use(function(req, res, next){
    res.cookie('XSRF-TOKEN', req.csrfToken());
    res.locals.csrftoken = req.csrfToken();
    next();
  });
  app.use('/public', express.static(staticDir, { maxAge: maxAge }));
  app.use(express.errorHandler());
  app.set('view cache', true);
}

app.use(function(req, res, next) {
  if(req.get('user-agent').match(/Android|BlackBerry|iPhone|iPad|Opera Mini|IEMobile/i))
    req.ua = 'm';
  else
    req.ua = 'd';
  next();
});

app.use(app.router);                                                                                         
           
app.use(express.static(path.join(__dirname, 'public')));                                                     
 
// routes           
routes(app);

http.createServer(app).listen(app.get('port'), function(){                                                   
  log.info('xs server listening on port ' + app.get('port'));                                                
});
