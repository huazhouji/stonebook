var xss = require('xss');
var html = xss('<script>alert("xss");</script>');
html = xss('xs0210456@gmail.com');
console.log(html);
