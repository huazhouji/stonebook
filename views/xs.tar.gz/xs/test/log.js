var winston = require('winston');

winston.loggers.add('db', {
    console: {
      silent: false,
      level: 'debug',
      colorize: true,
      timestamp: true
    },
    file: {
      silent: true,
      level: 'debug',
      colorize: true,
      timestamp: true,
      json: false,
      maxsize: 1024*1024*200,
      maxFiles: 10,
      filename: 'dbout.log'
    }
  });

var dblog = winston.loggers.get('db');

dblog.info('youtube is good');
dblog.warn('ly is awesome');
