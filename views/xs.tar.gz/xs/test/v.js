var v = require('validator');
console.log(v.isNull(v.trim('   ')));
